CREATE TABLE `digital_products` (
	`id` int AUTO_INCREMENT NOT NULL,
	`order_id` int NOT NULL,
	`product_name` varchar(255) NOT NULL,
	`file_name` varchar(255) NOT NULL,
	`s3_key` varchar(500) NOT NULL,
	`file_size` int,
	`download_url` text,
	`expires_at` timestamp,
	`download_count` int NOT NULL DEFAULT 0,
	`last_downloaded_at` timestamp,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `digital_products_id` PRIMARY KEY(`id`)
);
